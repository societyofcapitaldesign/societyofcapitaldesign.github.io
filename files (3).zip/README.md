# Society of Capital Design, website

Five sheet site plus a login protected editor at admin.html. Content
(events, essay cycles, results, chapters, leadership, numbers,
Bulletin issues, emails) lives in Supabase and is edited entirely on
the site itself. No code editing needed after setup.

## First time setup
Follow SETUP-SUPABASE.txt, six steps, about ten minutes. In short:
run supabase-setup.sql in the Supabase SQL Editor, turn off public
sign ups, create the founder logins, paste the project URL and anon
key into config.js, push everything to GitHub, Netlify deploys it.

## Day to day editing
Go to yoursite.netlify.app/admin.html, sign in, use the tabs. Photos
and PDFs upload from your phone. Saves are live within seconds.

## Files
* index.html, about.html, events.html, newsletter.html, join.html:
  the five public sheets
* admin.html: the editor (login required, accounts created only by
  the founders in Supabase)
* config.js: the two Supabase values, filled once during setup
* supabase-setup.sql and SETUP-SUPABASE.txt: one time setup
* scd-logo.jpg: the logo used in every header
* HOW-TO-EDIT.txt: editing guide and publishing rules
