-- SCD site database. Paste this whole file into the Supabase SQL
-- Editor and click Run. Safe to run more than once.

create table if not exists settings (
  key text primary key,
  value text default ''
);

create table if not exists events (
  id bigint generated always as identity primary key,
  name text not null,
  date_text text default '',
  venue text default '',
  description text default '',
  photo_url text default '',
  photo_alt text default '',
  is_next boolean default false,
  sort int default 100
);

create table if not exists cycles (
  id bigint generated always as identity primary key,
  name text not null,
  status text default '',
  deadline_text text default '',
  econ_prompts text default '',
  eng_prompts text default '',
  is_current boolean default false
);

create table if not exists results (
  id bigint generated always as identity primary key,
  title text not null,
  meta text default '',
  winner text default '',
  photo_url text default '',
  photo_alt text default '',
  sort int default 100
);

create table if not exists chapters (
  id bigint generated always as identity primary key,
  school text not null,
  lead text default '',
  chartered text default '',
  sort int default 100
);

create table if not exists leaders (
  id bigint generated always as identity primary key,
  name text default '',
  role text not null,
  photo_url text default '',
  sort int default 100
);

create table if not exists ledger (
  id bigint generated always as identity primary key,
  description text not null,
  qty text default '',
  sort int default 100
);

create table if not exists issues (
  id bigint generated always as identity primary key,
  title text not null,
  date_text text default '',
  link_url text default '',
  sort int default 100
);

-- security: anyone may read, only logged in founders may change
do $$
declare t text;
begin
  foreach t in array array['settings','events','cycles','results','chapters','leaders','ledger','issues']
  loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists "public read" on %I', t);
    execute format('create policy "public read" on %I for select using (true)', t);
    execute format('drop policy if exists "founders write" on %I', t);
    execute format('create policy "founders write" on %I for all to authenticated using (true) with check (true)', t);
  end loop;
end $$;

-- photo and PDF storage
insert into storage.buckets (id, name, public)
values ('media','media', true)
on conflict (id) do nothing;

drop policy if exists "public read media" on storage.objects;
create policy "public read media" on storage.objects
  for select using (bucket_id = 'media');
drop policy if exists "founders upload media" on storage.objects;
create policy "founders upload media" on storage.objects
  for insert to authenticated with check (bucket_id = 'media');
drop policy if exists "founders manage media" on storage.objects;
create policy "founders manage media" on storage.objects
  for update to authenticated using (bucket_id = 'media');
drop policy if exists "founders delete media" on storage.objects;
create policy "founders delete media" on storage.objects
  for delete to authenticated using (bucket_id = 'media');

-- starter rows: placeholders until the founders fill them in the editor
insert into ledger (description, qty, sort)
select * from (values
  ('School chapters','',1),
  ('Registered members','',2),
  ('Entries, latest essay cycle','',3),
  ('Bulletin issues published','',4)
) v(description, qty, sort)
where not exists (select 1 from ledger);

insert into leaders (name, role, sort)
select * from (values
  ('','Co founder · Economics',1),
  ('','Co founder · Engineering',2),
  ('','Head of Marketing',3),
  ('','Head of Operations',4)
) v(name, role, sort)
where not exists (select 1 from leaders);

insert into settings (key, value)
values ('contact_email',''),('join_email',''),('submissions_email',''),
       ('subscribe_email',''),('essay_word_limit',''),('charter_requirements','')
on conflict (key) do nothing;
