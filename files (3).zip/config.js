// SCD site configuration. Fill in the two values below ONCE, from your
// Supabase dashboard: Settings, then API.
// Project URL looks like https://abcdefgh.supabase.co
// Use the anon public key (starts with eyJ). NEVER put the service_role key here.
window.SCD_CONFIG = {
  url: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  anonKey: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};
